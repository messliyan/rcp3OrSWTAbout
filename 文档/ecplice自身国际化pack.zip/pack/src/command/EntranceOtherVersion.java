package command;

import java.io.FileOutputStream;

import util.ChangeFile;
import util.EctractZip;
import util.Zip;

public class EntranceOtherVersion {
	public static final String packageName = "SqlDeveloper-2.6.3-S001-111207";
	
	public static final String filePath = "F:\\test\\com.bonc.xcloud.client.application.product_2.6.0\\target\\XCLOUD.zip";
	public static final String zipPath = "F:\\test\\com.bonc.xcloud.client.application.product_2.6.0\\target";
	public static final String changeFilePath = zipPath + "\\"+packageName+"\\configuration\\config.ini";
	public static final String addFilePath = "C:\\Users\\Lyq\\Desktop\\���ʻ�.txt";
	public static final String pacagePath = "C:\\Users\\Lyq\\Desktop\\cirroData";
	
	public static void main(String[] args) {
		
//		ChangeFile.removeDir(zipPath + "\\" + "SqlDeveloper-2.6.1.16-108863");
		
		System.out.println("��ʼ��ѹ");
		EctractZip z = new EctractZip();
		z.Ectract(filePath, zipPath); // ���ؽ�ѹ���������ļ��б�
		System.out.println("��ѹ���");
		
		ChangeFile.changeDirName(zipPath +"\\XCloud-win32.win32.x86",
				zipPath +"\\"+ packageName);
		
		StringBuffer file = ChangeFile.getFile(changeFilePath);
		StringBuffer addfile = ChangeFile.getFile(addFilePath);
		String data = ChangeFile.updateFile("jar@4", addfile.toString(), file.toString());
		Boolean putFile = ChangeFile.putFile(changeFilePath, data);
		if(putFile){
			System.out.println("�ļ��޸ĳɹ�");
		}else{
			System.out.println("�ļ��޸�ʧ��");
		}
		Boolean changeFileName = ChangeFile.changeFileName(zipPath +"\\"+packageName+"\\eclipsec.exe",
				zipPath +"\\" + packageName + "\\XCloud_cli.exe");
		if(changeFileName){
			System.out.println("�ļ��������ɹ�");
		}else{
			System.out.println("�ļ�������ʧ��");
		}
		
		System.out.println("�ļ���ʼѹ��");
		FileOutputStream os;
		try {
			os = new FileOutputStream(pacagePath +"\\"+packageName+".zip");
			Zip.compress(os, zipPath+"\\" + packageName);
		} catch (Exception e) {
			e.printStackTrace();
		} 
//		ChangeFile.removeDir(zipPath +"\\"+packageName);
		System.out.println("ѹ������");
	}
}
