package command;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;

import util.ChangeFile;
import util.EctractZip;
import util.Zip;

public class EntranceConfJre {
	
	
	//需要修改的路径 product工程目录
	public static final String ProductPath = "D:\\Download\\com.bonc.xcloud.client.application.product";
	

	public static final String packageNameWin32 = "CirroData-win32.win32.x86.zip";
	public static final String packageNameWin64 = "CirroData-win32.win32.x86_64.zip";
	
	public static final String packageNameMacosx64 = "CirroData-macosx.cocoa.x86_64.zip";
	public static final String packageNameLinux64 = "CirroData-linux.gtk.x86_64.zip";
		
	
	//被解压 --压缩包
	public static final String filePathWin32 = ProductPath+"\\target\\products\\"+packageNameWin32;
	public static final String filePathWin64 = ProductPath+"\\target\\products\\"+packageNameWin64;
	
	public static final String filePathMacosx64 = ProductPath+"\\target\\products\\"+packageNameMacosx64;
	public static final String filePathLinux64 = ProductPath+"\\target\\products\\"+packageNameLinux64;
	
	
	
	//需要修改的路径 解压到 --文件夹  总路径
	public static final String zipPath = "C:\\Users\\PC\\Desktop\\cirroData";
	
	
	
	//拷贝路径conf
	public static final String CopyConfPath = ProductPath+"\\conf";
	
	//拷贝路径jre
	public static final String CopyJreWin32Path = ProductPath+"\\jre\\32";
	public static final String CopyJreWin64Path = ProductPath+"\\jre\\64";
	
	
	public static void main(String[] args) {
		
//		ChangeFile.removeDir(zipPath + "\\" + "SqlDeveloper-2.6.1.16-108863");
		
		System.out.println("开始解压文件");
		EctractZip z = new EctractZip();
		z.Ectract(filePathWin32, zipPath+"\\cirrodata\\win32\\win32\\x86"); // 返回解压缩出来Win32的文件列表
		z.Ectract(filePathWin64, zipPath+"\\cirrodata\\win32\\win32\\x86_64"); // 返回解压缩出来Win64的文件列表
		
		z.Ectract(filePathMacosx64, zipPath+"\\cirrodata\\macosx\\cocoa\\x86_64"); 
		z.Ectract(filePathLinux64, zipPath+"\\cirrodata\\linux\\gtk\\x86_64"); 
		
		
		System.out.println("文件解压完成");
		
		System.out.println("开始文件复制");
		
		try {
			FileUtil.copy(CopyJreWin32Path, zipPath+"\\cirrodata\\win32\\win32\\x86");
			FileUtil.copy(CopyJreWin64Path, zipPath+"\\cirrodata\\win32\\win32\\x86_64");
			
			FileUtil.copy(CopyConfPath, zipPath+"\\cirrodata\\win32\\win32\\x86\\conf");
			FileUtil.copy(CopyConfPath, zipPath+"\\cirrodata\\win32\\win32\\x86_64\\conf");
			FileUtil.copy(CopyConfPath, zipPath+"\\cirrodata\\macosx\\cocoa\\x86_64\\Eclipse.app\\Contents\\MacOS\\conf");
			FileUtil.copy(CopyConfPath, zipPath+"\\cirrodata\\linux\\gtk\\x86_64\\conf");
			
		} catch (Exception e) {
			// TODO 自动生成的 catch 块
			e.printStackTrace();
		}
		System.out.println("文件复制完成");
		
		System.out.println("文件开始压缩");
		FileOutputStream os;
		try {
			os = new FileOutputStream(zipPath +"\\"+packageNameWin32);
			Zip.compress(os, zipPath+"\\cirrodata\\win32\\win32\\x86");
			
			os = new FileOutputStream(zipPath +"\\"+packageNameWin64);
			Zip.compress(os, zipPath+"\\cirrodata\\win32\\win32\\x86_64");
			
			os = new FileOutputStream(zipPath +"\\"+packageNameMacosx64);
			Zip.compress(os, zipPath+"\\cirrodata\\macosx\\cocoa\\x86_64");
			
			os = new FileOutputStream(zipPath +"\\"+packageNameLinux64);
			Zip.compress(os, zipPath+"\\cirrodata\\linux\\gtk\\x86_64");
			
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		System.out.println("文件压缩完成");
	}
}
