package command;

import java.io.FileOutputStream;

import util.ChangeFile;
import util.EctractZip;
import util.Zip;

public class EntranceTrunk {
	public static final String packageName = /*"SqlDeveloper-2.6.5-S001-111586"*/"SqlDeveloper-2.8.4-S004_udf-117229"
			/*"SqlDeveloper-2.6.5-S001_dataLake_111611"*/;
	
	public static final String filePath = "F:\\workspace32\\com.bonc.xcloud.client.application.product\\target\\CirroData.zip";
	public static final String zipPath = "F:\\workspace32\\com.bonc.xcloud.client.application.product\\target";
	public static final String changeFilePath = zipPath + "\\"+packageName+"\\configuration\\config.ini";
	public static final String addFilePath = "C:\\Users\\PC\\Desktop\\国际化.txt";
	public static final String pacagePath = "C:\\Users\\PC\\Desktop\\cirroData";
	
	public static void main(String[] args) {
		
//		ChangeFile.removeDir(zipPath + "\\" + "SqlDeveloper-2.6.1.16-108863");
		
		System.out.println("开始解压");
		EctractZip z = new EctractZip();
		z.Ectract(filePath, zipPath); // 返回解压缩出来的文件列表
		System.out.println("解压完成");
		
		ChangeFile.changeDirName(zipPath +"\\CirroData-win32.win32.x86",
				zipPath +"\\"+ packageName);
		
		StringBuffer file = ChangeFile.getFile(changeFilePath);
		StringBuffer addfile = ChangeFile.getFile(addFilePath);
		String data = ChangeFile.updateFile("jar@4", addfile.toString(), file.toString());
		Boolean putFile = ChangeFile.putFile(changeFilePath, data);
		if(putFile){
			System.out.println("文件修改成功");
		}else{
			System.out.println("文件修改失败");
		}
		Boolean changeFileName = ChangeFile.changeFileName(zipPath +"\\"+packageName+"\\eclipsec.exe",
				zipPath +"\\" + packageName + "\\CirroData_cli.exe");
		if(changeFileName){
			System.out.println("文件重命名成功");
		}else{
			System.out.println("文件重命名失败");
		}
		
		System.out.println("文件开始压缩");
		FileOutputStream os;
		try {
			os = new FileOutputStream(pacagePath + "\\" + packageName + ".zip");
			Zip.compress(os, zipPath+"\\" + packageName);
		} catch (Exception e) {
			e.printStackTrace();
		} 
//		ChangeFile.removeDir(zipPath +"\\"+packageName);
		System.out.println("压缩结束");
	}
}
