package util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class ChangeFile {

	public static StringBuffer getFile(String fileName){
		StringBuffer sb = new StringBuffer();
		BufferedReader br = null;  
		 try { 
            File filename = new File(fileName); 
            InputStreamReader reader = new InputStreamReader(
                    new FileInputStream(filename)); 
            String line;
            br = new BufferedReader(reader); 
            while ((line = br.readLine()) != null) {
                sb.append(line);
                sb.append("\r\n");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
        	if(br != null){
        		try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
        	}
        }
		 return sb;
	}
	
	public static String updateFile(String regex,String addString,String file){
		String result = null;
		String[] split = file.split(regex);
		if(file.contains(addString)){
			//�Ѵ���
			return file;
		}
		if(split.length > 1){
			split[split.length -2] += regex + addString;
		}
		for (int i = 0; i < split.length; i++) {
			if(i < split.length - 2){
				result += split[i] + regex;
			}else{
				result += split[i];
			}
		}
		return result;
	}
	
	public static Boolean putFile(String filePath,String data){
		 try {
            File file = new File(filePath); 
//            if (file.exists() && file.isFile()) {
//            	boolean delete = file.delete();
//                System.out.println("ɾ��ԭ�ļ���"+delete);
//                if(!delete){
//                	return false;
//                }
//            }
            file.createNewFile(); 
            BufferedWriter out = new BufferedWriter(new FileWriter(file));
            out.write(data);
            out.flush(); // �ѻ���������ѹ���ļ�
            out.close(); 
        } catch (IOException e) {
            e.printStackTrace();
        }
		 return true;
	}

	public static Boolean changeFileName(String oldFile,String newFile){
		File toBeRenamed = new File(oldFile);
        //���Ҫ���������ļ��Ƿ���ڣ��Ƿ����ļ�
        if (!toBeRenamed.exists() || toBeRenamed.isDirectory()) {
            return false;
        }
 
        File newFiles = new File(newFile);
 
        //�޸��ļ���
        if (toBeRenamed.renameTo(newFiles)) {
            System.out.println("File has been renamed.");
            return true;
        } else {
            System.out.println("Error renmaing file");
            return false;
        }

	}
	public static Boolean changeDirName(String oldDoc,String newDoc){
		File toBeRenamed = new File(oldDoc);
		//���Ҫ���������ļ��Ƿ���ڣ��Ƿ����ļ�
		if (!toBeRenamed.exists() || !toBeRenamed.isDirectory()) {
			return false;
		}
		
		File newFiles = new File(newDoc);
		
		//�޸��ļ���
		if (toBeRenamed.renameTo(newFiles)) {
			System.out.println("Doc has been renamed.");
			return true;
		} else {
			System.out.println("Error renmaing file");
			return false;
		}
		
	}

	public static Boolean removeDir(String dirPath){
		File file = new File(dirPath);
		// ���ҽ����˳���·������ʾ���ļ������� ��һ��Ŀ¼ʱ������ true
		if (!file.isDirectory()) {
		    file.delete();
		} else if (file.isDirectory()) {
		    String[] filelist = file.list();
		    for (int i = 0; i < filelist.length; i++) {
		        File delfile = new File(dirPath + "\\" + filelist[i]);
		        if (!delfile.isDirectory()) {
		            delfile.delete();
		            System.out.println(delfile.getAbsolutePath() + "ɾ���ļ��ɹ�");
		        } else if (delfile.isDirectory()) {
		        	removeDir(dirPath + "\\" + filelist[i]);
		        }
		    }
		    System.out.println(file.getAbsolutePath() + "ɾ���ɹ�");
		    file.delete();
		}
        return true;
	}
}
